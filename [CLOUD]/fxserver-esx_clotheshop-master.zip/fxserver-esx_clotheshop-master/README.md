# fxserver-esx_clotheshop
FXServer ESX ClotheShop

[REQUIREMENTS]

- esx_skin => https://github.com/FXServer-ESX/fxserver-esx_skin

[INSTALLATION]

1) CD in your resources/[esx] folder
2) Clone the repository
```
git clone https://github.com/FXServer-ESX/fxserver-esx_clotheshop clotheshop
```
3) Add this in your server.cfg :

```
start esx_clotheshop
```
