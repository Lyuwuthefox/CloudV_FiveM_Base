Locales['fr'] = {

	['valid_this_purchase'] = 'valider cet achat ?',
	['yes'] = 'oui',
	['no'] = 'non',
	['name_outfit'] = 'nom de la tenue ?',
	['not_enough_money'] = 'vous n\'avez pas assez d\'argent',
	['press_menu'] = 'appuyez sur ~INPUT_CONTEXT~ pour accéder au menu',
	['clothes'] = 'vêtements',
	['you_paid'] = 'vous avez payé $',

}
