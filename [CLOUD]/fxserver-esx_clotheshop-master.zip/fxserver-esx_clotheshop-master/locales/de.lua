Locales['de'] = {

	['valid_this_purchase'] = 'Einkauf bestätigen?',
	['yes'] = 'ja',
	['no'] = 'nein',
	['name_outfit'] = 'Name des Outfits?',
	['not_enough_money'] = 'du hast nicht genug Geld',
	['press_menu'] = 'Drücke ~INPUT_CONTEXT~ um das Menü zu öffnen',
	['clothes'] = 'Kleidung',
	['you_paid'] = 'du bezahlst $',

}
