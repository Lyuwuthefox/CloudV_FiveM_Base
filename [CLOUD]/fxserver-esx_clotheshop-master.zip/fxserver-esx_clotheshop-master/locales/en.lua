Locales['en'] = {

	['valid_this_purchase'] = 'validate this purchase?',
	['yes'] = 'yes',
	['no'] = 'no',
	['name_outfit'] = 'name of the outfit?',
	['not_enough_money'] = 'you do not have enough money',
	['press_menu'] = 'press ~INPUT_CONTEXT~ to access the menu',
	['clothes'] = 'clothes',
	['you_paid'] = 'you paid $',

}
